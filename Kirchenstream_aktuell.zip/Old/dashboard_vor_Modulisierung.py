# === DASHBOARD START ===

import os
import time
import json
import requests
import logging
import http.server
import socketserver
import threading
import xml.etree.ElementTree as ET
import psutil
import subprocess
from datetime import datetime, timedelta
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from obswebsocket import obsws, requests as obs_requests

PORT = 5000
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
XML_DIR = os.path.join(BASE_DIR, "data")
HTML_OUTPUT_PATH = os.path.join(BASE_DIR, "index.html")

TELEGRAM_CREDENTIALS_PATH = os.path.join(BASE_DIR, "secrets", "telegram_stgisela.json")
YOUTUBE_TOKEN_PATH = os.path.join(BASE_DIR, "secrets", "token.json")
OBS_CONFIG_PATH = os.path.join(BASE_DIR, "secrets", "obs_credentials.json")
MAIN_FLAG_PATH = os.path.join(BASE_DIR, "runtime_flags", "main_done.flag")

DASHBOARD_HEARTBEAT_PATH = os.path.join(BASE_DIR, "status", "dashboard_heartbeat.txt")
MAIN_HEARTBEAT_PATH = os.path.join(BASE_DIR, "status", "main_heartbeat.json")

SCOPES = ['https://www.googleapis.com/auth/youtube.force-ssl']

# === OBS Client ===

class OBSClient:
    def __init__(self, host="localhost", port=4455, password=""):
        self.host = host
        self.port = port
        self.password = password
        self.ws = None
        self.lock = threading.Lock()
        self.connected = False
        self.last_scene = None

    def connect(self):
        try:
            if self.ws:
                self.ws.disconnect()
        except:
            pass
        try:
            self.ws = obsws(self.host, self.port, self.password)
            self.ws.connect()
            self.connected = True
            logging.info("✅ OBS WebSocket verbunden.")
        except Exception as e:
            self.connected = False
            logging.warning(f"OBS-Verbindung fehlgeschlagen: {e}")

    def get_scene(self):
        with self.lock:
            if not self.connected:
                self.connect()
                if not self.connected:
                    return None
            try:
                response = self.ws.call(obs_requests.GetCurrentProgramScene())
                self.last_scene = response.getSceneName()
                return self.last_scene
            except Exception as e:
                logging.warning(f"Fehler beim Abrufen der OBS-Szene: {e}")
                self.connected = False
                return None

# === OBS CLIENT INIT ===
try:
    with open(OBS_CONFIG_PATH, "r") as f:
        obs_cfg = json.load(f)
except:
    obs_cfg = {}

obs_client = OBSClient(
    host="localhost",
    port=obs_cfg.get("port", 4455),
    password=obs_cfg.get("password", "")
)


confirmed_live_ids = set()
error_mode_until = None
live_check_triggered = False
live_check_start = None
active_stream_id = None
lock = threading.Lock()

logging.basicConfig(
    filename=os.path.join(BASE_DIR, "dashboard.log"),
    level=logging.INFO,
    format='[%(asctime)s] %(levelname)s: %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)


# ------------------- HTML TEMPLATE -------------------

HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8">
<script>
(function() {{
    try {{
        const theme = localStorage.getItem("theme") || "dark";
        document.documentElement.className = theme;
    }} catch (e) {{
        document.documentElement.className = "dark";
    }}
}})();
</script>
<meta http-equiv="refresh" content="10">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
    html.dark body {{
        background-color: #121212;
        color: white;
    }}
    html.light body {{
        background-color: #f4f4f4;
        color: #111;
    }}
    body {{
        margin: 0; padding: 16px;
        font-family: 'Segoe UI', sans-serif;
        font-size: 13px;
        transition: background-color 0.3s, color 0.3s;
    }}
    .row {{
        margin-bottom: 10px;
        padding: 4px;
        border-bottom: 1px solid #444;
    }}
    .label {{
        font-size: 11px;
        color: #888;
    }}
    .status {{
        font-weight: 500;
        font-size: 14px;
        display: block;
        margin-top: 2px;
    }}
    .green {{ color: #4CAF50; }}
    .yellow {{ color: #FFD700; }}
    .red {{ color: #FF5555; }}
    .gray {{ color: #888888; }}
    .white {{ color: #ffffff; }}
    a {{ color: #4FC3F7; text-decoration: none; }}
    a:hover {{ text-decoration: underline; }}
    .top-bar {{
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 10px;
    }}
    .clock {{
        font-size: 12px;
    }}
    .toggle-btn {{
        padding: 4px 10px;
        font-size: 11px;
        background: #444;
        color: white;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }}
</style>
<script>
    function toggleTheme() {{
        const html = document.documentElement;
        const isDark = html.classList.contains("dark");
        if (isDark) {{
            html.classList.remove("dark");
            html.classList.add("light");
            localStorage.setItem("theme", "light");
        }} else {{
            html.classList.remove("light");
            html.classList.add("dark");
            localStorage.setItem("theme", "dark");
        }}
    }}
    function updateClock() {{
        const now = new Date();
        const clock = document.getElementById("clock");
        clock.textContent = now.toLocaleTimeString('de-DE');
    }}
    window.onload = function () {{
        const savedTheme = localStorage.getItem("theme") || "dark";
        document.documentElement.classList.add(savedTheme);
        setInterval(updateClock, 1000);
        updateClock();
    }};
</script>
</head>
<body>
<div class="top-bar">
    <button class="toggle-btn" onclick="toggleTheme()">🌓 Darkmode</button>
    <div class="clock" id="clock">⏳</div>
</div>

<div class="row"><span class="label">Titel</span><span class="status">🎬 {title}</span></div>
<div class="row"><span class="label">Datum / Uhrzeit nächster Stream</span><span class="status">📅 {datetime_text}</span></div>
<div class="row"><span class="label">Stream Key</span><span class="status">🗝️ {key}</span></div>
<div class="row"><span class="label">YouTube-Link</span><span class="status">🔗 <a href="{video_url}" target="_blank">{video_url}</a></span></div>
<div class="row"><span class="label">Stream-Status</span><span class="status {status_color}">📡 {status_text}</span></div>
<div class="row"><span class="label">Kamera-Modus</span><span class="status {camera_hint_color}">📷 {camera_hint}</span></div>
<div class="row"><span class="label">Remote-Steuerung</span><span class="status {remote_color}">{remote_text}</span></div>
<div class="row"><span class="label">main.py Status</span><span class="status {main_color}">🧠 {main_status}</span></div>
</body>
</html>
"""



# === HEARTBEAT ===

def write_dashboard_heartbeat():
    os.makedirs(os.path.dirname(DASHBOARD_HEARTBEAT_PATH), exist_ok=True)
    with open(DASHBOARD_HEARTBEAT_PATH, "w", encoding="utf-8") as f:
        f.write(datetime.now().isoformat())

def read_main_heartbeat():
    try:
        with open(MAIN_HEARTBEAT_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
            ts = datetime.fromisoformat(data.get("timestamp"))
            return data.get("state", ""), ts
    except:
        return "", None

def was_main_shut_down_cleanly():
    return os.path.exists(MAIN_FLAG_PATH)


# === YouTube Livestatus ===

def get_youtube_livestatus(broadcast_id):
    try:
        creds = Credentials.from_authorized_user_file(YOUTUBE_TOKEN_PATH, SCOPES)
        youtube = build("youtube", "v3", credentials=creds)
        request = youtube.liveBroadcasts().list(part="status", id=broadcast_id)
        response = request.execute()
        if not response["items"]:
            return None
        return response["items"][0]["status"]["lifeCycleStatus"]
    except Exception as e:
        logging.error(f"Fehler beim Abrufen des YouTube-Status: {e}")
        return None

# === NÄCHSTER STREAM ===

def get_next_stream():
    try:
        now = datetime.now()
        candidates = []
        for offset in range(2):
            month = (now + timedelta(days=offset*31)).strftime("%Y-%m")
            path = os.path.join(XML_DIR, f"streams_{month}.xml")
            if os.path.exists(path):
                tree = ET.parse(path)
                root = tree.getroot()
                for s in root.findall("stream"):
                    dt = datetime.strptime(s.find("date").text + " " + s.find("time").text, "%Y-%m-%d %H:%M")
                    if dt > now:
                        stream_id = s.find("video_url").text.split("/")[-1]
                        if stream_id not in confirmed_live_ids and stream_id != active_stream_id:
                            candidates.append((dt, s))
        candidates.sort(key=lambda x: x[0])
        if candidates:
            return candidates[0][1]
        return None
    except Exception as e:
        logging.error(f"Fehler beim Lesen des nächsten Streams: {e}")
        return None

# === HTML BAUEN ===

def build_html(title, key, video_url, datetime_text, status_text, status_color,
               camera_hint, camera_hint_color, remote_color, remote_text,
               main_color, main_status):
    try:
        html = HTML_TEMPLATE.format(
            title=title,
            key=key,
            video_url=video_url,
            datetime_text=datetime_text,
            status_text=status_text,
            status_color=status_color,
            camera_hint=camera_hint,
            camera_hint_color=camera_hint_color,
            remote_color=remote_color,
            remote_text=remote_text,
            main_color=main_color,
            main_status=main_status
        )
        with open(HTML_OUTPUT_PATH, "w", encoding="utf-8") as f:
            f.write(html)
    except Exception as e:
        logging.error(f"Fehler beim Schreiben der HTML-Datei: {e}")

# === STATUS-LOGIK ===

def update_status():
    global confirmed_live_ids, error_mode_until, live_check_triggered, live_check_start, active_stream_id

    title, key, video_url, datetime_text = "-", "-", "#", "-"
    status_text = "Kein geplanter Stream"
    status_color = "gray"
    camera_hint = "Automatik Modus"
    camera_hint_color = "red"
    remote_color = "gray"
    remote_text = "📶 St. Gisela #Off – kein Stream"

    try:
        scene = obs_client.get_scene()
        now = datetime.now()
        broadcast_id = None

        next_stream = get_next_stream()
        if next_stream is not None:
            candidate_id = next_stream.find("video_url").text.split("/")[-1]

            if active_stream_id and active_stream_id in confirmed_live_ids:
                broadcast_id = active_stream_id
            else:
                broadcast_id = candidate_id
                title = next_stream.find("title").text
                key = next_stream.find("key").text
                video_url = next_stream.find("video_url").text or "#"
                sched_dt = datetime.strptime(next_stream.find("date").text + " " + next_stream.find("time").text, "%Y-%m-%d %H:%M")
                datetime_text = sched_dt.strftime("%Y-%m-%d %H:%M")
                delta = (sched_dt - timedelta(minutes=5) - now).total_seconds()

        if scene and scene.lower() == "gottesdienst" and broadcast_id:
            camera_hint = "📷 Manuell – bitte Steuerung übernehmen"
            camera_hint_color = "yellow"

            status = get_youtube_livestatus(broadcast_id)
            if status == "live":
                with lock:
                    confirmed_live_ids.add(broadcast_id)
                active_stream_id = broadcast_id
                error_mode_until = None
            elif error_mode_until is None:
                error_mode_until = now + timedelta(minutes=120)

        if not scene or scene.lower() != "gottesdienst":
            camera_hint = "Automatik Modus"
            camera_hint_color = "red"

        if error_mode_until and now > error_mode_until:
            with lock:
                confirmed_live_ids.discard(broadcast_id)
            error_mode_until = None
            live_check_triggered = False

        if broadcast_id:
            with lock:
                if broadcast_id in confirmed_live_ids:
                    status_text = "✅ Stream läuft"
                    status_color = "green"
                elif next_stream is not None:
                    sched_dt = datetime.strptime(next_stream.find("date").text + " " + next_stream.find("time").text, "%Y-%m-%d %H:%M")
                    delta = (sched_dt - timedelta(minutes=5) - now).total_seconds()
                    if delta > 0:
                        status_text = f"⏳ {int(delta // 60)} Minuten bis Streamstart"
                        status_color = "white"
                    elif -120 <= delta <= 0:
                        status_text = "⏳ Warte auf YouTube..."
                        status_color = "white"
                    elif -2700 <= delta < -120:
                        status_text = "✅ Stream läuft (vermutlich)"
                        status_color = "green"
                    else:
                        status_text = "🔴 Stream beendet – Overlay schließt in 10 Min"
                        status_color = "yellow"

        try:
            with open(TELEGRAM_CREDENTIALS_PATH, "r", encoding="utf-8") as f:
                creds = json.load(f)
            url = f"https://api.telegram.org/bot{creds['token']}/getUpdates"
            r = requests.get(url)
            if r.status_code == 200:
                last_valid_cmd = None
                for u in updates:
                    msg = u.get("message", {})
                    if str(msg.get("chat", {}).get("id")) == str(creds["chat_id"]):
                        txt = msg.get("text", "").strip().lower()
                        if "#on" in txt or "#off" in txt:
                            last_valid_cmd = txt
                            break  # ← weil updates schon mit [::-1] rückwärts sortiert sind (neueste zuerst)

                if last_valid_cmd:
                    if "#on" in last_valid_cmd:
                        remote_color = "green"
                        remote_text = "📶 St. Gisela #On – Stream läuft"
                    elif "#off" in last_valid_cmd:
                        remote_color = "gray"
                        remote_text = "📶 St. Gisela #Off – kein Stream"

        except Exception as e:
            logging.warning(f"Telegram-Verbindungsfehler: {e}")

    except Exception as e:
        logging.error(f"Unbekannter Fehler in update_status(): {e}")

    state, ts = read_main_heartbeat()
    ts_ok = ts and datetime.now() - ts < timedelta(seconds=90)

    if ts_ok:
        main_status = "läuft"
        main_color = "green"
    elif state == "planned_exit" or was_main_shut_down_cleanly():
        main_status = "planmäßig beendet"
        main_color = "yellow"
    else:
        main_status = "abgestürzt"
        main_color = "red"

    build_html(title, key, video_url, datetime_text, status_text, status_color,
               camera_hint, camera_hint_color, remote_color, remote_text,
               main_color, main_status)

# === WATCHDOG ===

def main_watchdog_loop():
    while True:
        try:
            state, ts = read_main_heartbeat()
            now = datetime.now()
            too_old = not ts or (now - ts > timedelta(seconds=90))
            unclean_shutdown = state != "planned_exit"

            main_running = False
            for proc in psutil.process_iter(attrs=["cmdline"]):
                try:
                    if "main.py" in " ".join(proc.info["cmdline"]):
                        main_running = True
                        break
                except:
                    continue

            if not main_running and too_old and unclean_shutdown:
                logging.warning("❌ main.py abgestürzt erkannt – Neustart wird eingeleitet...")
                for proc in psutil.process_iter(attrs=["pid", "cmdline"]):
                    try:
                        if "main.py" in " ".join(proc.info["cmdline"]):
                            os.kill(proc.info["pid"], 9)
                            logging.warning(f"🛠️ Alter main.py-Prozess {proc.info['pid']} wurde beendet.")
                    except:
                        pass
                subprocess.Popen(["python", os.path.join(BASE_DIR, "main.py")], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                logging.info("🚀 main.py wurde neu gestartet.")
        except Exception as e:
            logging.error(f"Fehler im main.py-Watchdog: {e}")
        time.sleep(30)

# === SERVER ===

def start_dashboard():
    class CustomHandler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            try:
                if self.path in ("/", "/index.html"):
                    with open(HTML_OUTPUT_PATH, "rb") as f:
                        content = f.read()
                    self.send_response(200)
                    self.send_header("Content-type", "text/html; charset=utf-8")
                    self.send_header("Content-length", str(len(content)))
                    self.end_headers()
                    self.wfile.write(content)
                else:
                    self.send_error(404, "Nicht gefunden")
            except Exception as e:
                logging.error(f"Fehler im Handler: {e}")
                self.send_error(500, "Serverfehler")

        def log_message(self, format, *args):
            return

    os.makedirs(os.path.dirname(HTML_OUTPUT_PATH), exist_ok=True)
    update_status()

    socketserver.TCPServer.allow_reuse_address = True
    httpd = socketserver.TCPServer(("127.0.0.1", PORT), CustomHandler)

    def run_webserver():
        try:
            httpd.serve_forever()
        except Exception as e:
            logging.error(f"Fehler im Webserver-Thread: {e}")

    def run_updater():
        while True:
            try:
                update_status()
                write_dashboard_heartbeat()
                time.sleep(10)
            except Exception as e:
                logging.error(f"Fehler im Updater-Thread: {e}")

    threading.Thread(target=run_webserver, daemon=True).start()
    threading.Thread(target=run_updater, daemon=True).start()
    threading.Thread(target=main_watchdog_loop, daemon=True).start()

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        httpd.shutdown()

# === ENTRYPOINT ===

if __name__ == "__main__":
    start_dashboard()