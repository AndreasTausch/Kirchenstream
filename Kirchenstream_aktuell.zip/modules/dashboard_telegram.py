import os
import json
import requests
import logging

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TELEGRAM_CREDENTIALS_PATH = os.path.join(BASE_DIR, "..", "secrets", "telegram_stgisela.json")

def get_latest_telegram_status():
    try:
        with open(TELEGRAM_CREDENTIALS_PATH, "r", encoding="utf-8") as f:
            creds = json.load(f)

        url = f"https://api.telegram.org/bot{creds['token']}/getUpdates"
        r = requests.get(url)
        if r.status_code != 200:
            return "gray", "📶 St. Gisela #Off – kein Stream"

        updates = r.json().get("result", [])[::-1]
        for u in updates:
            msg = u.get("message", {})
            if str(msg.get("chat", {}).get("id")) == str(creds["chat_id"]):
                txt = msg.get("text", "").strip().lower()
                if "#on" in txt:
                    return "green", "📶 St. Gisela #On – Stream läuft"
                elif "#off" in txt:
                    return "gray", "📶 St. Gisela #Off – kein Stream"
        return "gray", "📶 St. Gisela #Off – kein Stream"

    except Exception as e:
        logging.warning(f"Telegram-Verbindungsfehler: {e}")
        return "gray", "📶 St. Gisela #Off – kein Stream"
