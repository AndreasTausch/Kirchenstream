import os
import sys
import time
import threading

# Dynamische Pfade setzen
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODULES_DIR = os.path.join(BASE_DIR, "modules")
sys.path.insert(0, MODULES_DIR)

# Externe Imports
from modules.dashboard_obs import OBSClient
from modules.dashboard_status import update_status
from modules.dashboard_html import HTML_OUTPUT_PATH
from modules.dashboard_heartbeat import write_dashboard_heartbeat
from modules.dashboard_watchdog import main_watchdog_loop
from http.server import BaseHTTPRequestHandler
import socketserver

PORT = 5000

# === SERVER ===

def start_dashboard():
    class CustomHandler(BaseHTTPRequestHandler):
        def do_GET(self):
            try:
                if self.path in ("/", "/index.html"):
                    with open(HTML_OUTPUT_PATH, "rb") as f:
                        content = f.read()
                    self.send_response(200)
                    self.send_header("Content-type", "text/html; charset=utf-8")
                    self.send_header("Content-length", str(len(content)))
                    self.end_headers()
                    self.wfile.write(content)
                else:
                    self.send_error(404, "Nicht gefunden")
            except Exception as e:
                print(f"Fehler im Handler: {e}")
                self.send_error(500, "Serverfehler")

        def log_message(self, format, *args):
            return

    socketserver.TCPServer.allow_reuse_address = True
    httpd = socketserver.TCPServer(("127.0.0.1", PORT), CustomHandler)

    def run_webserver():
        try:
            httpd.serve_forever()
        except Exception as e:
            print(f"Fehler im Webserver-Thread: {e}")

    def run_updater():
        while True:
            try:
                update_status()
                write_dashboard_heartbeat()
                time.sleep(10)
            except Exception as e:
                print(f"Fehler im Updater-Thread: {e}")

    threading.Thread(target=run_webserver, daemon=True).start()
    threading.Thread(target=run_updater, daemon=True).start()
    threading.Thread(target=main_watchdog_loop, daemon=True).start()

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        httpd.shutdown()

# === ENTRYPOINT ===
if __name__ == "__main__":
    start_dashboard()
